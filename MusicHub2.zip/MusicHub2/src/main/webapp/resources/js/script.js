var app = angular.module("MusicApp", []);
app.controller("myController", ["$scope" ,function($scope) {
$scope.cds = [
                    { id:"101",
                    	name: "cd",
                    	price: "100.00"},
                    	{ id:"201",
                        	name: "vcd",
                        	price: "200.00"},
                        	{ id:"301",
                            	name: "pcd",
                            	price: "300.00"}
	                    			];               	
                  
}]);
