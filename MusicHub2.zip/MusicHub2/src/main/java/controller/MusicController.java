package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MusicController{
      @RequestMapping("/welcome")  
     public ModelAndView helloWorld(){
       ModelAndView model=new ModelAndView("index");
          
       return model;
    }
      @RequestMapping("/login")  
      public ModelAndView login(){
        ModelAndView model=new ModelAndView("login");
          
        return model;
     }
      @RequestMapping("/register")  
      public ModelAndView register(){
        ModelAndView model=new ModelAndView("register");
           
        return model;
}
      

      @RequestMapping(value="/button1",  method=RequestMethod.GET)
      public  ModelAndView button1(){

      ModelAndView model=new ModelAndView("button");
      model.addObject("id","102");
      model.addObject("name","cd");
      model.addObject("price","102.00");
      return model;
      }
      @RequestMapping(value="/button2",  method=RequestMethod.GET)
      public  ModelAndView button2(){

      ModelAndView model=new ModelAndView("button");
      model.addObject("id","202");
      model.addObject("name","vcd");
      model.addObject("price","204.00");
      return model;
      }
      @RequestMapping(value="/button3",  method=RequestMethod.GET)
      public  ModelAndView button3(){

      ModelAndView model=new ModelAndView("button");
      model.addObject("id","303");
      model.addObject("name","pcd");
      model.addObject("price","300.00");
      return model;
      }
      @RequestMapping(value="/details",  method=RequestMethod.GET)
      public  ModelAndView details(){

      ModelAndView model=new ModelAndView("button1");
           
      return model;
      }


}


