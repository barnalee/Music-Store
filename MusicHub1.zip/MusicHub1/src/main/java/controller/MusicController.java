package controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


import org.springframework.web.servlet.ModelAndView;

@Controller
public class MusicController{
      @RequestMapping("/welcome")  
     public ModelAndView helloWorld(){
       ModelAndView model=new ModelAndView("index");
          
       return model;
    }
      @RequestMapping("/login")  
      public ModelAndView login(){
        ModelAndView model=new ModelAndView("login");
           
        return model;
     }
      @RequestMapping("/register")  
      public ModelAndView register(){
        ModelAndView model=new ModelAndView("register");
           
        return model;
}
      @RequestMapping("/button")  
      public ModelAndView button(){
        ModelAndView model=new ModelAndView("button");
           
        return model;
}


}


